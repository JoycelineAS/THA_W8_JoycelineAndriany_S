﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace THA_W8
{
    public partial class Form1 : Form
    {
        string mode = "";
        
        public Form1()
        {
            InitializeComponent();
        }

        DBConnection conn = new DBConnection();
        private void Form1_Load(object sender, EventArgs e)
        {
            reset();
        }

        private void reloadTeam()
        {
            SelectionMode selectionMode = lbPlayer.SelectionMode;
            lbTeam.SelectionMode = SelectionMode.None;
            lbTeam.DataSource = null;
            lbTeam.Visible = true;
            DataTable data = conn.execQuery("SELECT team_id, team_name, home_stadium, capacity, city, manager_id, assmanager_id, captain_id, `delete` FROM team;");

            lbTeam.DataSource = data;
            lbTeam.DisplayMember = "team_name";
            lbTeam.SelectionMode = selectionMode;
        }
        private void reloadPlayer()
        {
            SelectionMode selectionMode = lbPlayer.SelectionMode;
            lbPlayer.SelectionMode = SelectionMode.None;
            lbPlayer.DataSource = null;
            lbPlayer.Visible = true;
            string team_id = ((DataRowView)lbTeam.SelectedItem)["team_id"].ToString();

            DataTable data = conn.execQuery("SELECT player_id, team_number, player_name, nationality_id, playing_pos, height, weight, birthdate, team_id, status, `delete` FROM player WHERE team_id = '" + team_id + "';");

            lbPlayer.DataSource = data;
            lbPlayer.DisplayMember = "player_name";
            lbPlayer.SelectionMode = selectionMode;
        }
        private void reloadMatch()
        {
            SelectionMode selectionMode = lbMatch.SelectionMode;
            lbMatch.SelectionMode = SelectionMode.None;
            lbMatch.DataSource = null;
            lbMatch.Visible = true;
            string team_id = ((DataRowView)lbTeam.SelectedItem)["team_id"].ToString();

            DataTable data = conn.execQuery(@"
SELECT  match_id, match_date, team_home, team_away, goal_home, goal_away, referee_id, m.`delete`,
t1.team_name as team_name_home, t2.team_name as team_name_away,
CASE WHEN t1.team_id='"+team_id+@"' THEN t2.team_name ELSE t1.team_name END as vs
FROM `match` m
INNER JOIN team t1 on t1.team_id = m.team_home
INNER JOIN team t2 on t2.team_id = m.team_away
WHERE team_home = '"+team_id+"' OR team_away = '"+team_id+"';");

            lbMatch.DataSource = data;
            lbMatch.DisplayMember = "vs";
            lbMatch.SelectionMode = selectionMode;
        }

        private void lbPlayer_SelectedIndexChanged(object sender, EventArgs e)
        {
            string player_id = ((DataRowView)lbPlayer.SelectedItem)["player_id"].ToString();

            DataTable data = conn.execQuery(@"
               SELECT 
                   p.player_name,t.team_name, p.playing_pos, p.team_number, n.nation,
                   SUM(CASE WHEN d.type = 'CY' THEN 1 ELSE 0 END) as yellow_card,
                   SUM(CASE WHEN d.type = 'CR' THEN 1 ELSE 0 END) as red_card,
                   SUM(CASE WHEN d.type = 'GO' THEN 1 ELSE 0 END) as goal,
                   SUM(CASE WHEN d.type = 'GP' THEN 1 ELSE 0 END) as goal_penalty,
                   SUM(CASE WHEN d.type = 'GW' THEN 1 ELSE 0 END) as own_goal,
                   SUM(CASE WHEN d.type = 'PM' THEN 1 ELSE 0 END) as penalty_miss
                FROM player p
                INNER JOIN team t on p.team_id = t.team_id
                INNER JOIN nationality n on p.nationality_id = n.nationality_id
                LEFT JOIN dmatch d on p.player_id = d.player_id
                WHERE p.player_id='"+ player_id + @"'
                GROUP BY p.player_id");
            DataRow player = data.Rows[0];
            string player_name = player["player_name"].ToString();
            string team_name = player["team_name"].ToString();
            string playing_pos = player["playing_pos"].ToString();
            string team_number = player["team_number"].ToString();
            string nation  = player["nation"].ToString();
            string yellow_card = player["yellow_card"].ToString();
            string red_card = player["red_card"].ToString();
            string goal = player["goal"].ToString();
            string goal_penalty = player["goal_penalty"].ToString();
            string own_goal = player["own_goal"].ToString();
            string penalty_miss  = player["penalty_miss"].ToString();
            lblPlayerData.Text = @"Player Name: "+ player_name + @"
Team Name: "+team_name +@"
Playing Position: "+playing_pos +@"
Squad Number: "+team_number +@"
Nationality:  "+nation  +@"
Yellow Cards: "+yellow_card +@"
Red Cars: "+red_card +@"
Goal Scored: "+goal +@"
Goal Penalty: "+goal_penalty +@"
Own Goal: "+own_goal +@"
Penalty Missed: "+penalty_miss  +@"
            ";
        }
        private void lbTeam_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (mode == "Player Data")
            {
                reloadPlayer();
                return;
            }
            if (mode == "Show Match Details")
            {
                reloadMatch();
                return;
            }
        }
        private void reset() {
            lblPlayerData.Text = "";
            lblMatchData.Text = "";
            lblHomePlayers.Text = "";
            lblAwayPlayers.Text = "";
            lbTeam.Visible = false;
            lbPlayer.Visible = false;
            lbMatch.Visible = false;
        }

        private void playerDataToolStripMenuItem_Click(object sender, EventArgs e)
        {
            mode = "Player Data";
            reset();
            reloadTeam();
        }

        private void showMatchDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            mode = "Show Match Details";
            reset();
            reloadTeam();
        }

        private void lbMatch_SelectedIndexChanged(object sender, EventArgs e)
        {

            string match_id = ((DataRowView)lbMatch.SelectedItem)["match_id"].ToString();
            string team_away_id = ((DataRowView)lbMatch.SelectedItem)["team_away"].ToString();
            string team_home_id = ((DataRowView)lbMatch.SelectedItem)["team_home"].ToString();
            string team_name_away = ((DataRowView)lbMatch.SelectedItem)["team_name_away"].ToString();
            string team_name_home = ((DataRowView)lbMatch.SelectedItem)["team_name_home"].ToString();
            loadTeamPlayersToLabel(team_away_id, team_name_away + " [AWAY]", lblAwayPlayers);
            loadTeamPlayersToLabel(team_home_id, team_name_home + " [HOME]", lblHomePlayers);
            loadMatchData(match_id);

        }

        private void loadMatchData(string matchId) {
            lblMatchData.Text = "";
            DataTable data = conn.execQuery(@"SELECT d.minute, d.type,
                   t.team_name, p.player_name
                FROM dmatch d
            INNER JOIN team t on t.team_id = d.team_id
            INNER JOIN player p on d.player_id = p.player_id
            WHERE d.match_id = '"+ matchId + "';");

            for (int i = 0; i < data.Rows.Count; i++)
            {
                DataRow row = data.Rows[i];
                string minute = row["minute"].ToString();
                string type = row["type"].ToString();
                string team_name = row["team_name"].ToString();
                string player_name  = row["player_name"].ToString();

                switch (type)
                {
                    case "CY":
                        type = "Yellow Card" + "("+type+")";
                        break;
                    case "CR": 
                        type = "Red Card" + "("+type+")";
                        break;
                    case "GO": 
                        type = "Goal" + "("+type+")";
                        break;
                    case "GP": 
                        type = "Goal Penalty" + "("+type+")";
                        break;
                    case "GW": 
                        type = "Own Goal" + "("+type+")";
                        break;
                    case "PM": 
                        type = "Penalty Miss" + "("+type+")";
                        break;
                    case "":
                        break;
                    default:
                        break;
                }
                lblMatchData.Text += "Minute: "+minute+"  ,TeamName: "+team_name+"  ,Player: "+player_name+"  ,Type: "+type+"\n";

            }
        }
        private void loadTeamPlayersToLabel(string teamId, string teamName, Label label)
        {
            label.Text = teamName + "\n\n";

            DataTable data = conn.execQuery(@"SELECT player_id, 
team_number, 
player_name, 
nationality_id, 
playing_pos, 
height, 
weight, 
birthdate, 
team_id, 
status, 
`delete` FROM player WHERE team_id = '" + teamId + "';");

            for (int i = 0; i < data.Rows.Count; i++)
            {
                DataRow player = data.Rows[i];
                string player_name = player["player_name"].ToString();
                string player_pos = player["playing_pos"].ToString();
                label.Text += player_pos + " - " + player_name +  "\n";

            }
        }
    }
}
