﻿namespace THA_W8
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.playerDataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.showMatchDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lbTeam = new System.Windows.Forms.ListBox();
            this.lbPlayer = new System.Windows.Forms.ListBox();
            this.lblPlayerData = new System.Windows.Forms.Label();
            this.lbMatch = new System.Windows.Forms.ListBox();
            this.lblMatchData = new System.Windows.Forms.Label();
            this.lblHomePlayers = new System.Windows.Forms.Label();
            this.lblAwayPlayers = new System.Windows.Forms.Label();
            this.menuStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip2
            // 
            this.menuStrip2.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip2.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.playerDataToolStripMenuItem,
            this.showMatchDetailsToolStripMenuItem});
            this.menuStrip2.Location = new System.Drawing.Point(0, 0);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Size = new System.Drawing.Size(1503, 33);
            this.menuStrip2.TabIndex = 3;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // playerDataToolStripMenuItem
            // 
            this.playerDataToolStripMenuItem.Name = "playerDataToolStripMenuItem";
            this.playerDataToolStripMenuItem.Size = new System.Drawing.Size(117, 29);
            this.playerDataToolStripMenuItem.Text = "Player Data";
            this.playerDataToolStripMenuItem.Click += new System.EventHandler(this.playerDataToolStripMenuItem_Click);
            // 
            // showMatchDetailsToolStripMenuItem
            // 
            this.showMatchDetailsToolStripMenuItem.Name = "showMatchDetailsToolStripMenuItem";
            this.showMatchDetailsToolStripMenuItem.Size = new System.Drawing.Size(184, 29);
            this.showMatchDetailsToolStripMenuItem.Text = "Show Match Details";
            this.showMatchDetailsToolStripMenuItem.Click += new System.EventHandler(this.showMatchDetailsToolStripMenuItem_Click);
            // 
            // lbTeam
            // 
            this.lbTeam.FormattingEnabled = true;
            this.lbTeam.ItemHeight = 20;
            this.lbTeam.Location = new System.Drawing.Point(18, 78);
            this.lbTeam.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.lbTeam.Name = "lbTeam";
            this.lbTeam.Size = new System.Drawing.Size(178, 144);
            this.lbTeam.TabIndex = 0;
            this.lbTeam.SelectedIndexChanged += new System.EventHandler(this.lbTeam_SelectedIndexChanged);
            // 
            // lbPlayer
            // 
            this.lbPlayer.FormattingEnabled = true;
            this.lbPlayer.ItemHeight = 20;
            this.lbPlayer.Location = new System.Drawing.Point(207, 78);
            this.lbPlayer.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.lbPlayer.Name = "lbPlayer";
            this.lbPlayer.Size = new System.Drawing.Size(178, 144);
            this.lbPlayer.TabIndex = 1;
            this.lbPlayer.SelectedIndexChanged += new System.EventHandler(this.lbPlayer_SelectedIndexChanged);
            // 
            // lblPlayerData
            // 
            this.lblPlayerData.AutoSize = true;
            this.lblPlayerData.Location = new System.Drawing.Point(14, 255);
            this.lblPlayerData.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPlayerData.Name = "lblPlayerData";
            this.lblPlayerData.Size = new System.Drawing.Size(102, 20);
            this.lblPlayerData.TabIndex = 2;
            this.lblPlayerData.Text = "lblPlayerData";
            // 
            // lbMatch
            // 
            this.lbMatch.FormattingEnabled = true;
            this.lbMatch.ItemHeight = 20;
            this.lbMatch.Location = new System.Drawing.Point(207, 78);
            this.lbMatch.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.lbMatch.Name = "lbMatch";
            this.lbMatch.Size = new System.Drawing.Size(178, 144);
            this.lbMatch.TabIndex = 3;
            this.lbMatch.SelectedIndexChanged += new System.EventHandler(this.lbMatch_SelectedIndexChanged);
            // 
            // lblMatchData
            // 
            this.lblMatchData.AutoSize = true;
            this.lblMatchData.Location = new System.Drawing.Point(1020, 101);
            this.lblMatchData.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMatchData.Name = "lblMatchData";
            this.lblMatchData.Size = new System.Drawing.Size(103, 20);
            this.lblMatchData.TabIndex = 4;
            this.lblMatchData.Text = "lblMatchData";
            // 
            // lblHomePlayers
            // 
            this.lblHomePlayers.AutoSize = true;
            this.lblHomePlayers.Location = new System.Drawing.Point(483, 78);
            this.lblHomePlayers.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblHomePlayers.Name = "lblHomePlayers";
            this.lblHomePlayers.Size = new System.Drawing.Size(103, 20);
            this.lblHomePlayers.TabIndex = 5;
            this.lblHomePlayers.Text = "lblMatchData";
            // 
            // lblAwayPlayers
            // 
            this.lblAwayPlayers.AutoSize = true;
            this.lblAwayPlayers.Location = new System.Drawing.Point(711, 78);
            this.lblAwayPlayers.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAwayPlayers.Name = "lblAwayPlayers";
            this.lblAwayPlayers.Size = new System.Drawing.Size(103, 20);
            this.lblAwayPlayers.TabIndex = 6;
            this.lblAwayPlayers.Text = "lblMatchData";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1503, 808);
            this.Controls.Add(this.lblMatchData);
            this.Controls.Add(this.lblAwayPlayers);
            this.Controls.Add(this.lblHomePlayers);
            this.Controls.Add(this.menuStrip2);
            this.Controls.Add(this.lbMatch);
            this.Controls.Add(this.lblPlayerData);
            this.Controls.Add(this.lbTeam);
            this.Controls.Add(this.lbPlayer);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblPlayerData;
        private System.Windows.Forms.ListBox lbPlayer;
        private System.Windows.Forms.ListBox lbTeam;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem playerDataToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem showMatchDetailsToolStripMenuItem;
        private System.Windows.Forms.Label lblAwayPlayers;
        private System.Windows.Forms.Label lblHomePlayers;
        private System.Windows.Forms.Label lblMatchData;
        private System.Windows.Forms.ListBox lbMatch;
    }
}

